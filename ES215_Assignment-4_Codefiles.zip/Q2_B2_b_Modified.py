import numpy as np
import time

n=int(input("Enter size of matrix: "))

mat1=np.random.randint(low=1,high=32767,size=(n,n))
mat2=np.random.randint(low=1,high=32767,size=(n,n))
mat3 = np.zeros((n,n))

start=time.time_ns()

for i in range (n):
  for j in range (n):
    for k in range (n):
      mat3[i][j] += mat1[i][k] * mat2[k][j]

end=time.time_ns()

# print(mat3)

print("Time taken for matrix multiplication in seconds", (end-start)*1e-9)